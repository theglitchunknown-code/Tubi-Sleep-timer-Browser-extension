(async () => {
  const $ = (id) => document.getElementById(id);
  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

  let settings = await getSettings();
  applyTheme(settings.colors);

  /* ---------- saving ---------- */
  let saveTimer = null;
  const setStatus = (t) => { $("status").textContent = t; };

  async function saveNow() {
    clearTimeout(saveTimer);
    await chrome.storage.local.set({ settings });
    setStatus("Saved ✓");
  }
  function queueSave() {
    setStatus("Saving…");
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNow, 300);
  }

  /* ---------- warnings ---------- */
  function renderWarnings() {
    const wrap = $("warnings");
    wrap.textContent = "";

    settings.warnings.forEach((w, i) => {
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `
        <div class="card-head">
          <label class="toggle"><input type="checkbox" class="en"> <strong>Warning ${i + 1}</strong></label>
          <span><span class="pv-note muted"></span> <button type="button" class="preview">Preview</button></span>
        </div>
        <div class="fields">
          <div class="field"><span>Warn me</span>
            <input type="number" class="mm" min="0" max="120"> <span>min</span>
            <input type="number" class="ss" min="0" max="59"> <span>sec</span>
            <span class="muted">before closing</span></div>
          <div class="field col"><span>Message</span>
            <input type="text" class="msg" maxlength="120"></div>
          <label class="check"><input type="checkbox" class="ov"> Show popup on the Tubi page</label>
          <label class="check"><input type="checkbox" class="nt"> Show system notification</label>
          <label class="check"><input type="checkbox" class="cd"> Show live seconds countdown <span class="muted cdnote"></span></label>
          <div class="field"><span>Auto-hide popup after</span>
            <input type="number" class="ha" min="0" max="120"> <span>sec</span>
            <span class="muted">(0 = stay until dismissed)</span></div>
        </div>`;

      const q = (s) => card.querySelector(s);
      const en = q(".en"), mm = q(".mm"), ss = q(".ss"), msg = q(".msg");
      const ov = q(".ov"), nt = q(".nt"), cd = q(".cd"), ha = q(".ha");
      const cdnote = q(".cdnote"), pvNote = q(".pv-note");

      en.checked = w.enabled;
      mm.value = Math.floor(w.seconds / 60);
      ss.value = w.seconds % 60;
      msg.value = w.message;
      ov.checked = w.overlay;
      nt.checked = w.notify;
      cd.checked = w.countdown;
      ha.value = w.hideAfter;

      const sync = () => {
        const canCount = w.seconds <= 60;
        cd.disabled = !canCount;
        if (!canCount) { w.countdown = false; cd.checked = false; }
        cdnote.textContent = canCount ? "" : "(only for 60 seconds or less)";
        ha.disabled = w.countdown && canCount;
        card.classList.toggle("off", !w.enabled);
      };
      sync();

      const onTime = () => {
        const m = clamp(parseInt(mm.value, 10) || 0, 0, 120);
        const s = clamp(parseInt(ss.value, 10) || 0, 0, 59);
        w.seconds = Math.max(1, m * 60 + s);
        sync();
        queueSave();
      };
      mm.addEventListener("input", onTime);
      ss.addEventListener("input", onTime);
      const normalize = () => {
        mm.value = Math.floor(w.seconds / 60);
        ss.value = w.seconds % 60;
      };
      mm.addEventListener("change", normalize);
      ss.addEventListener("change", normalize);

      en.addEventListener("change", () => { w.enabled = en.checked; sync(); queueSave(); });
      msg.addEventListener("input", () => { w.message = msg.value; queueSave(); });
      ov.addEventListener("change", () => { w.overlay = ov.checked; queueSave(); });
      nt.addEventListener("change", () => { w.notify = nt.checked; queueSave(); });
      cd.addEventListener("change", () => { w.countdown = cd.checked; sync(); queueSave(); });
      ha.addEventListener("input", () => { w.hideAfter = clamp(parseInt(ha.value, 10) || 0, 0, 120); queueSave(); });

      q(".preview").addEventListener("click", async () => {
        await saveNow();
        pvNote.textContent = "";
        try {
          const res = await chrome.runtime.sendMessage({ type: "preview", id: w.id });
          if (!w.overlay) pvNote.textContent = w.notify ? "Notification sent." : "Nothing to preview (popup is off).";
          else if (!res || !res.shown) pvNote.textContent = "Open a Tubi tab to preview the popup.";
          else pvNote.textContent = `Shown on ${res.shown} Tubi tab${res.shown > 1 ? "s" : ""}.`;
        } catch (e) {
          pvNote.textContent = "Couldn't reach the extension.";
        }
        setTimeout(() => { pvNote.textContent = ""; }, 5000);
      });

      wrap.appendChild(card);
    });
  }

  /* ---------- general ---------- */
  function bindGeneral() {
    const ext = $("extendMinutes");
    ext.value = settings.extendMinutes;
    ext.addEventListener("input", () => {
      settings.extendMinutes = clamp(parseInt(ext.value, 10) || 10, 1, 720);
      queueSave();
    });
    ext.addEventListener("change", () => { ext.value = settings.extendMinutes; });

    $("showBadge").checked = settings.showBadge;
    $("showBadge").addEventListener("change", (e) => { settings.showBadge = e.target.checked; queueSave(); });
    $("alwaysShowTimer").checked = settings.alwaysShowTimer;
    $("alwaysShowTimer").addEventListener("change", (e) => { settings.alwaysShowTimer = e.target.checked; queueSave(); });
  }

  /* ---------- after close ---------- */
  // Auto-start needs access to the link's site (YouTube is built in; others ask once).
  async function ensureHostAccess(url) {
    const n = normalizeUrl(url);
    if (!n) return true;
    const pattern = new URL(n).origin + "/*";
    try {
      if (await chrome.permissions.contains({ origins: [pattern] })) return true;
      const ok = await chrome.permissions.request({ origins: [pattern] });
      if (!ok) $("linkNote").textContent = "Without access to that site, auto-start is skipped.";
      return ok;
    } catch (_) {
      return false;
    }
  }

  function updateLinkNote() {
    const raw = settings.afterClose.link.url;
    const n = normalizeUrl(raw);
    $("linkNote").textContent = !raw
      ? "Paste the link to open."
      : n
        ? `Will open: ${new URL(n).hostname}`
        : "That doesn't look like a valid web link.";
  }

  function bindAfter() {
    const a = settings.afterClose;
    const le = $("linkEnabled"), lu = $("linkUrl"), ap = $("linkAutoPlay");
    const be = $("blackEnabled"), fsEl = $("blackFullscreen"), dl = $("blackDelay");
    le.checked = a.link.enabled;
    if (document.activeElement !== lu) lu.value = a.link.url;
    ap.checked = a.link.autoPlay;
    be.checked = a.black.enabled;
    fsEl.checked = a.black.fullscreen;
    if (document.activeElement !== dl) dl.value = a.black.delaySeconds;
    updateLinkNote();

    // Property handlers (not addEventListener) so re-binding never stacks listeners.
    le.onchange = () => {
      settings.afterClose.link.enabled = le.checked;
      queueSave();
      if (le.checked && settings.afterClose.link.autoPlay) ensureHostAccess(settings.afterClose.link.url);
    };
    lu.oninput = () => { settings.afterClose.link.url = lu.value.trim(); updateLinkNote(); queueSave(); };
    ap.onchange = () => {
      settings.afterClose.link.autoPlay = ap.checked;
      queueSave();
      if (ap.checked) ensureHostAccess(settings.afterClose.link.url);
    };
    be.onchange = () => { settings.afterClose.black.enabled = be.checked; queueSave(); };
    fsEl.onchange = () => { settings.afterClose.black.fullscreen = fsEl.checked; queueSave(); };
    dl.oninput = () => {
      settings.afterClose.black.delaySeconds = clamp(parseInt(dl.value, 10) || 0, 0, 20);
      queueSave();
    };
    dl.onchange = () => { dl.value = settings.afterClose.black.delaySeconds; };
  }

  $("testAfter").addEventListener("click", async () => {
    const a = settings.afterClose;
    if (a.link.enabled && a.link.autoPlay) await ensureHostAccess(a.link.url);
    await saveNow();
    const note = $("testNote");
    try {
      const r = await chrome.runtime.sendMessage({ type: "test-after" });
      if (r && r.linkInvalid) note.textContent = "The link is on but isn't a valid web link.";
      else if (!r || (!r.link && !r.black)) note.textContent = "Turn on a switch above first.";
      else note.textContent = r.link && r.black
        ? "Started. The black screen appears after the wait. Press Esc there to leave fullscreen."
        : "Opened.";
    } catch (e) {
      note.textContent = "Couldn't reach the extension.";
    }
    setTimeout(() => { note.textContent = ""; }, 5000);
  });

  // Keep the switches in sync if they're flipped from the toolbar popup.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.settings || !changes.settings.newValue) return;
    const incoming = mergeSettings(changes.settings.newValue).afterClose;
    if (JSON.stringify(incoming) !== JSON.stringify(settings.afterClose)) {
      settings.afterClose = incoming;
      bindAfter();
    }
  });

  /* ---------- colors ---------- */
  const COLOR_GROUPS = [
    {
      title: "Popup & settings",
      keys: [
        ["bg", "Background"],
        ["surface", "Panels & buttons"],
        ["border", "Borders"],
        ["text", "Text"],
        ["muted", "Secondary text"],
        ["accent", "Accent / primary buttons"],
        ["accentText", "Text on accent"],
        ["danger", "Cancel button"],
        ["success", "Status (Tubi playing)"]
      ]
    },
    {
      title: "On-page warning popup",
      keys: [
        ["overlayBg", "Background"],
        ["overlayText", "Text"],
        ["overlayAccent", "Accent & progress bar"],
        ["overlayCount", "Countdown number"]
      ]
    }
  ];

  function renderColors() {
    const wrap = $("colors");
    wrap.textContent = "";
    for (const group of COLOR_GROUPS) {
      const h = document.createElement("h3");
      h.textContent = group.title;
      wrap.appendChild(h);
      const grid = document.createElement("div");
      grid.className = "color-grid";

      for (const [key, label] of group.keys) {
        const row = document.createElement("div");
        row.className = "color-row";
        row.innerHTML = `<span class="name"></span><input type="color"><code></code><button type="button" title="Reset this color">↺</button>`;
        row.querySelector(".name").textContent = label;
        const input = row.querySelector("input");
        const code = row.querySelector("code");
        input.value = settings.colors[key];
        code.textContent = settings.colors[key];

        input.addEventListener("input", () => {
          settings.colors[key] = input.value;
          code.textContent = input.value;
          applyTheme(settings.colors);
          queueSave();
        });
        row.querySelector("button").addEventListener("click", () => {
          settings.colors[key] = DEFAULT_SETTINGS.colors[key];
          input.value = settings.colors[key];
          code.textContent = settings.colors[key];
          applyTheme(settings.colors);
          queueSave();
        });
        grid.appendChild(row);
      }
      wrap.appendChild(grid);
    }
  }

  $("resetColors").addEventListener("click", () => {
    settings.colors = structuredClone(DEFAULT_SETTINGS.colors);
    applyTheme(settings.colors);
    renderColors();
    queueSave();
  });

  $("resetAll").addEventListener("click", async () => {
    if (!confirm("Reset all settings (warnings, general options and colors) to defaults?")) return;
    settings = structuredClone(DEFAULT_SETTINGS);
    applyTheme(settings.colors);
    renderWarnings();
    bindGeneral();
    bindAfter();
    renderColors();
    await saveNow();
  });

  renderWarnings();
  bindGeneral();
  bindAfter();
  renderColors();
})();
