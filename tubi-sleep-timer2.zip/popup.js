const TUBI_URLS = [
  "*://tubitv.com/*",
  "*://*.tubitv.com/*",
  "*://tubi.tv/*",
  "*://*.tubi.tv/*"
];

const $ = (id) => document.getElementById(id);
let endTime = null;
let settings = null;

const send = (msg) => chrome.runtime.sendMessage(msg);

async function load() {
  settings = await getSettings();
  applyTheme(settings.colors);
  const { endTime: e } = await chrome.storage.local.get("endTime");
  endTime = e && e > Date.now() ? e : null;
  $("extend").textContent = `+${settings.extendMinutes} min`;
  syncAfter();
  render();
}

const pad = (n) => String(n).padStart(2, "0");

function fmtCountdown(ms) {
  const s = Math.max(0, Math.round(ms / 1000));
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}

function fmtTime(ts) {
  return new Date(ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function dayLabel(ts) {
  const mid = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const d = new Date(ts);
  const diff = Math.round((mid(d) - mid(new Date())) / 86400000);
  if (diff <= 0) return "";
  if (diff === 1) return "Tomorrow";
  return d.toLocaleDateString([], { weekday: "long" });
}

function render() {
  if (!settings) return;
  if (endTime && endTime <= Date.now()) endTime = null;

  const running = endTime !== null;
  $("active").hidden = !running;
  $("setup").hidden = running;
  if (!running) return;

  const left = endTime - Date.now();
  const lastMinute = left <= 60000;
  const count = $("count");

  if (lastMinute) {
    // The live countdown only appears in the final 60 seconds.
    $("bigLabel").textContent = "Closing in";
    count.textContent = Math.max(0, Math.ceil(left / 1000)) + "s";
    count.classList.add("urgent");
    $("remaining").textContent = "";
  } else {
    $("bigLabel").textContent = "Tubi closes at";
    count.textContent = fmtTime(endTime);
    count.classList.remove("urgent");
    const day = dayLabel(endTime);
    $("remaining").textContent = settings.alwaysShowTimer
      ? `Time left ${fmtCountdown(left)}`
      : day;
  }
}

async function refreshTabStatus() {
  const tabs = await chrome.tabs.query({ url: TUBI_URLS });
  const el = $("tabStatus");
  const playing = tabs.some((t) => t.audible);
  if (!tabs.length) {
    el.textContent = "No Tubi tab open right now";
    el.className = "status";
  } else {
    el.textContent = playing
      ? "Tubi is playing ✓"
      : `${tabs.length} Tubi tab${tabs.length > 1 ? "s" : ""} open`;
    el.className = "status ok";
  }
}

async function startIn(minutes) {
  if (!minutes || minutes < 1) return;
  minutes = Math.min(1440, minutes);
  await send({ type: "start", endTime: Date.now() + minutes * 60000 });
  await load();
}

function clockTarget() {
  const v = $("clock").value;
  if (!v) return null;
  const [h, m] = v.split(":").map(Number);
  const t = new Date();
  t.setHours(h, m, 0, 0);
  if (t.getTime() <= Date.now() + 5000) t.setDate(t.getDate() + 1);
  return t.getTime();
}

document.querySelectorAll(".chips button").forEach((b) => {
  b.addEventListener("click", () => startIn(Number(b.dataset.min)));
});

$("startCustom").addEventListener("click", () => startIn(Number($("customMin").value)));
$("customMin").addEventListener("keydown", (e) => {
  if (e.key === "Enter") startIn(Number($("customMin").value));
});

$("clock").addEventListener("input", () => {
  const t = clockTarget();
  if (!t) { $("clockHint").textContent = ""; return; }
  const day = dayLabel(t);
  $("clockHint").textContent = `Will close at ${fmtTime(t)}${day ? " (" + day.toLowerCase() + ")" : ""}`;
});

$("startClock").addEventListener("click", async () => {
  const t = clockTarget();
  if (!t) { $("clockHint").textContent = "Pick a time first."; return; }
  await send({ type: "start", endTime: t });
  await load();
});

$("extend").addEventListener("click", async () => {
  if (!endTime) return;
  await send({ type: "extend", minutes: settings.extendMinutes });
  await load();
});

$("cancel").addEventListener("click", async () => {
  await send({ type: "cancel" });
  await load();
});

function syncAfter() {
  const a = settings.afterClose;
  $("afterLink").checked = a.link.enabled;
  $("afterBlack").checked = a.black.enabled;
  const url = normalizeUrl(a.link.url);
  $("linkHint").textContent = url ? new URL(url).hostname : "add a link in Settings";
}

async function setAfter(mutate) {
  const s = await getSettings();
  mutate(s.afterClose);
  await chrome.storage.local.set({ settings: s });
}

$("afterLink").addEventListener("change", (e) => setAfter((a) => { a.link.enabled = e.target.checked; }));
$("afterBlack").addEventListener("change", (e) => setAfter((a) => { a.black.enabled = e.target.checked; }));

$("openSettings").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

chrome.storage.onChanged.addListener(load);
setInterval(render, 1000);
load();
refreshTabStatus();
