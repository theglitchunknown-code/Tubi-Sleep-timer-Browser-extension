// On-page warning popup. Lives in a closed shadow root so Tubi's CSS can't affect it.
(() => {
  if (window.__tubiSleepTimerLoaded) return;
  window.__tubiSleepTimerLoaded = true;

  const FALLBACK = {
    overlayBg: "#14111f",
    overlayText: "#ece9f5",
    overlayAccent: "#6d28d9",
    overlayCount: "#faf0c8"
  };

  let host = null;
  let tickTimer = null;
  let hideTimer = null;

  const safeColor = (c, fb) => (typeof c === "string" && /^#[0-9a-f]{3,8}$/i.test(c) ? c : fb);

  function onAccent(hex) {
    let h = hex.replace("#", "");
    if (h.length === 3) h = h.split("").map((c) => c + c).join("");
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    return (r * 299 + g * 587 + b * 114) / 1000 > 150 ? "#111111" : "#ffffff";
  }

  // In fullscreen only the fullscreen element's subtree is visible.
  function container() {
    const fs = document.fullscreenElement || document.webkitFullscreenElement;
    if (fs && fs.tagName !== "VIDEO" && fs.tagName !== "IFRAME") return fs;
    return document.documentElement;
  }

  function hide() {
    clearInterval(tickTimer);
    clearTimeout(hideTimer);
    tickTimer = hideTimer = null;
    if (host) {
      host.remove();
      host = null;
    }
  }

  function show(m) {
    hide();
    const c = m.colors || {};
    const bg = safeColor(c.overlayBg, FALLBACK.overlayBg);
    const text = safeColor(c.overlayText, FALLBACK.overlayText);
    const accent = safeColor(c.overlayAccent, FALLBACK.overlayAccent);
    const count = safeColor(c.overlayCount, FALLBACK.overlayCount);

    host = document.createElement("div");
    host.id = "tubi-sleep-timer-overlay";
    host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
    host.style.setProperty("--bg", bg);
    host.style.setProperty("--text", text);
    host.style.setProperty("--accent", accent);
    host.style.setProperty("--count", count);
    host.style.setProperty("--on-accent", onAccent(accent));

    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
      <style>
        .card {
          position: absolute; top: 28px; left: 50%; transform: translateX(-50%);
          min-width: 300px; max-width: min(92vw, 460px);
          background: var(--bg); color: var(--text);
          border: 1px solid var(--accent); border-radius: 14px;
          padding: 16px 18px; box-shadow: 0 10px 40px rgba(0,0,0,.55);
          font: 15px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif;
          pointer-events: auto; animation: pop .2s ease-out;
        }
        @keyframes pop { from { opacity: 0; transform: translate(-50%, -8px); } to { opacity: 1; transform: translate(-50%, 0); } }
        .msg { font-weight: 600; text-align: center; }
        .count { font-size: 46px; font-weight: 800; color: var(--count); text-align: center;
                 font-variant-numeric: tabular-nums; line-height: 1.1; margin: 8px 0; }
        .bar { height: 5px; border-radius: 3px; background: rgba(127,127,127,.3); overflow: hidden; margin: 6px 0 12px; }
        .bar span { display: block; height: 100%; width: 100%; background: var(--accent); }
        .row { display: flex; gap: 8px; justify-content: center; margin-top: 12px; }
        .bar + .row { margin-top: 0; }
        button { font: inherit; cursor: pointer; border-radius: 8px; padding: 7px 14px;
                 border: 1px solid var(--accent); background: transparent; color: var(--text); }
        button.ext { background: var(--accent); color: var(--on-accent); }
        [hidden] { display: none !important; }
      </style>
      <div class="card" role="alertdialog" aria-live="assertive">
        <div class="msg"></div>
        <div class="count" hidden></div>
        <div class="bar" hidden><span></span></div>
        <div class="row">
          <button class="ext"></button>
          <button class="dismiss">Dismiss</button>
        </div>
      </div>`;

    const msgEl = shadow.querySelector(".msg");
    const countEl = shadow.querySelector(".count");
    const barEl = shadow.querySelector(".bar");
    const fill = shadow.querySelector(".bar span");
    const extBtn = shadow.querySelector(".ext");
    const dismissBtn = shadow.querySelector(".dismiss");

    msgEl.textContent = m.message || "";
    extBtn.textContent = `+${m.extendMinutes || 10} min`;
    extBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "extend", minutes: m.extendMinutes || 10 });
      hide();
    });
    dismissBtn.addEventListener("click", hide);

    container().appendChild(host);

    if (m.countdown) {
      countEl.hidden = false;
      barEl.hidden = false;
      const total = Math.max(1, m.endTime - Date.now());
      const update = () => {
        const left = m.endTime - Date.now();
        if (left <= 0) {
          chrome.runtime.sendMessage({ type: "check-close" });
          hide();
          return;
        }
        countEl.textContent = Math.ceil(left / 1000) + "s";
        fill.style.width = Math.min(100, (left / total) * 100) + "%";
      };
      update();
      tickTimer = setInterval(update, 250);
    } else if (m.hideAfter > 0) {
      hideTimer = setTimeout(hide, m.hideAfter * 1000);
    }
  }

  document.addEventListener("fullscreenchange", () => {
    if (host) container().appendChild(host);
  });
  document.addEventListener("webkitfullscreenchange", () => {
    if (host) container().appendChild(host);
  });

  chrome.runtime.onMessage.addListener((m) => {
    if (!m) return;
    if (m.type === "tubi-sleep:show") show(m);
    else if (m.type === "tubi-sleep:hide") hide();
  });
})();
