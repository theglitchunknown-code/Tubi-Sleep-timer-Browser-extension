const hint = document.getElementById("hint");
setTimeout(() => { hint.style.opacity = "0"; }, 4000);

async function isFullscreen() {
  try {
    return (await chrome.windows.getCurrent()).state === "fullscreen";
  } catch (_) {
    return !!document.fullscreenElement;
  }
}

async function setFullscreen(on) {
  try {
    const w = await chrome.windows.getCurrent();
    if (on) {
      await chrome.storage.local.set({ preFsState: w.state === "fullscreen" ? "maximized" : w.state });
      await chrome.windows.update(w.id, { state: "fullscreen" });
    } else {
      const { preFsState } = await chrome.storage.local.get("preFsState");
      const back = preFsState && preFsState !== "fullscreen" ? preFsState : "maximized";
      await chrome.windows.update(w.id, { state: back });
    }
  } catch (_) {
    if (on) document.documentElement.requestFullscreen().catch(() => {});
    else if (document.fullscreenElement) document.exitFullscreen();
  }
}

async function toggle() {
  setFullscreen(!(await isFullscreen()));
}

document.addEventListener("click", toggle);
document.addEventListener("keydown", async (e) => {
  if (e.key === "f" || e.key === "F") toggle();
  else if (e.key === "Escape" && (await isFullscreen())) setFullscreen(false);
});
