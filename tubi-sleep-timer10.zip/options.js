(async () => {
  const $ = (id) => document.getElementById(id);
  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

  let settings = await getSettings();
  applyTheme(settings.colors);

  /* ---------- saving ---------- */
  let saveTimer = null;
  const setStatus = (t) => { $("status").textContent = t; };

  async function saveNow() {
    clearTimeout(saveTimer);
    await chrome.storage.local.set({ settings });
    setStatus("Saved ✓");
  }
  function queueSave() {
    refreshUi();
    setStatus("Saving…");
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNow, 300);
  }

  /* ---------- warnings ---------- */
  function renderWarnings() {
    const wrap = $("warnings");
    wrap.textContent = "";

    settings.warnings.forEach((w, i) => {
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `
        <div class="card-head">
          <label class="toggle"><input type="checkbox" class="en"> <strong>Warning ${i + 1}</strong></label>
          <span><span class="pv-note muted"></span> <button type="button" class="preview">Preview</button></span>
        </div>
        <div class="fields">
          <div class="field"><span>Warn me</span>
            <input type="number" class="mm" min="0" max="120"> <span>min</span>
            <input type="number" class="ss" min="0" max="59"> <span>sec</span>
            <span class="muted">before closing</span></div>
          <div class="field col"><span>Message</span>
            <input type="text" class="msg" maxlength="120"></div>
          <label class="check"><input type="checkbox" class="ov"> Show popup on the Tubi page</label>
          <label class="check"><input type="checkbox" class="nt"> Show system notification</label>
          <label class="check"><input type="checkbox" class="cd"> Show live seconds countdown <span class="muted cdnote"></span></label>
          <div class="field"><span>Auto-hide popup after</span>
            <input type="number" class="ha" min="0" max="120"> <span>sec</span>
            <span class="muted">(0 = stay until dismissed)</span></div>
        </div>`;

      const q = (s) => card.querySelector(s);
      const en = q(".en"), mm = q(".mm"), ss = q(".ss"), msg = q(".msg");
      const ov = q(".ov"), nt = q(".nt"), cd = q(".cd"), ha = q(".ha");
      const cdnote = q(".cdnote"), pvNote = q(".pv-note");

      en.checked = w.enabled;
      mm.value = Math.floor(w.seconds / 60);
      ss.value = w.seconds % 60;
      msg.value = w.message;
      ov.checked = w.overlay;
      nt.checked = w.notify;
      cd.checked = w.countdown;
      ha.value = w.hideAfter;

      const sync = () => {
        const canCount = w.seconds <= 60;
        cd.disabled = !canCount;
        if (!canCount) { w.countdown = false; cd.checked = false; }
        cdnote.textContent = canCount ? "" : "(only for 60 seconds or less)";
        ha.disabled = w.countdown && canCount;
        card.classList.toggle("off", !w.enabled);
      };
      sync();

      const onTime = () => {
        const m = clamp(parseInt(mm.value, 10) || 0, 0, 120);
        const s = clamp(parseInt(ss.value, 10) || 0, 0, 59);
        w.seconds = Math.max(1, m * 60 + s);
        sync();
        queueSave();
      };
      mm.addEventListener("input", onTime);
      ss.addEventListener("input", onTime);
      const normalize = () => {
        mm.value = Math.floor(w.seconds / 60);
        ss.value = w.seconds % 60;
      };
      mm.addEventListener("change", normalize);
      ss.addEventListener("change", normalize);

      en.addEventListener("change", () => { w.enabled = en.checked; sync(); queueSave(); });
      msg.addEventListener("input", () => { w.message = msg.value; queueSave(); });
      ov.addEventListener("change", () => { w.overlay = ov.checked; queueSave(); });
      nt.addEventListener("change", () => { w.notify = nt.checked; queueSave(); });
      cd.addEventListener("change", () => { w.countdown = cd.checked; sync(); queueSave(); });
      ha.addEventListener("input", () => { w.hideAfter = clamp(parseInt(ha.value, 10) || 0, 0, 120); queueSave(); });

      q(".preview").addEventListener("click", async () => {
        await saveNow();
        pvNote.textContent = "";
        try {
          const res = await chrome.runtime.sendMessage({ type: "preview", id: w.id });
          if (!w.overlay) pvNote.textContent = w.notify ? "Notification sent." : "Nothing to preview (popup is off).";
          else if (!res || !res.shown) pvNote.textContent = "Open a Tubi tab to preview the popup.";
          else pvNote.textContent = `Shown on ${res.shown} Tubi tab${res.shown > 1 ? "s" : ""}.`;
        } catch (e) {
          pvNote.textContent = "Couldn't reach the extension.";
        }
        setTimeout(() => { pvNote.textContent = ""; }, 5000);
      });

      wrap.appendChild(card);
    });
  }

  /* ---------- general ---------- */
  function bindGeneral() {
    const ext = $("extendMinutes");
    ext.value = settings.extendMinutes;
    ext.addEventListener("input", () => {
      settings.extendMinutes = clamp(parseInt(ext.value, 10) || 10, 1, 720);
      queueSave();
    });
    ext.addEventListener("change", () => { ext.value = settings.extendMinutes; });

    $("showBadge").checked = settings.showBadge;
    $("showBadge").addEventListener("change", (e) => { settings.showBadge = e.target.checked; queueSave(); });
    $("alwaysShowTimer").checked = settings.alwaysShowTimer;
    $("alwaysShowTimer").addEventListener("change", (e) => { settings.alwaysShowTimer = e.target.checked; queueSave(); });
  }

  /* ---------- simple view, easy reading, remove ---------- */
  const sameColors = (a, b) => Object.keys(DEFAULT_SETTINGS.colors).every((k) => a[k] === b[k]);

  function refreshUi() {
    const adv = settings.ui.mode === "advanced";
    document.body.classList.toggle("simple", !adv);
    $("modeSimple").setAttribute("aria-pressed", String(!adv));
    $("modeAdv").setAttribute("aria-pressed", String(adv));
    applyUi(settings.ui);
    document.querySelectorAll("#sizeChoices .choice").forEach((b) =>
      b.classList.toggle("selected", Number(b.dataset.size) === Number(settings.ui.textSize))
    );
    document.querySelectorAll("#themeChoices .choice").forEach((b) => {
      const preset = b.dataset.theme === "contrast" ? HIGH_CONTRAST_COLORS : DEFAULT_SETTINGS.colors;
      b.classList.toggle("selected", sameColors(settings.colors, preset));
    });
    $("warnMaster").checked = settings.warnings.some((w) => w.enabled);

    const mode = settings.stopAutoplay.mode === "show" ? "show" : "episode";
    document.querySelectorAll("#saModeChoices .choice").forEach((b) =>
      b.classList.toggle("selected", b.dataset.mode === mode)
    );
    $("saModeNote").textContent =
      mode === "show"
        ? "The next episodes of the same show keep playing. It stops when the show is finished and Tubi starts something different."
        : "It stops as soon as Tubi tries to start anything new after the episode you're watching.";
  }

  function bindLooks() {
    $("modeSimple").onclick = () => { settings.ui.mode = "simple"; queueSave(); window.scrollTo(0, 0); };
    $("modeAdv").onclick = () => { settings.ui.mode = "advanced"; queueSave(); window.scrollTo(0, 0); };

    document.querySelectorAll("#sizeChoices .choice").forEach((b) => {
      b.onclick = () => { settings.ui.textSize = Number(b.dataset.size); queueSave(); };
    });
    document.querySelectorAll("#themeChoices .choice").forEach((b) => {
      b.onclick = () => {
        settings.colors = structuredClone(
          b.dataset.theme === "contrast" ? HIGH_CONTRAST_COLORS : DEFAULT_SETTINGS.colors
        );
        applyTheme(settings.colors);
        renderColors();
        queueSave();
      };
    });

    $("warnMaster").onchange = () => {
      const on = $("warnMaster").checked;
      settings.warnings.forEach((w) => { w.enabled = on; });
      renderWarnings();
      queueSave();
    };

    $("uninstall").onclick = async () => {
      const note = $("uninstallNote");
      note.textContent = "";
      try {
        await chrome.management.uninstallSelf({ showConfirmDialog: true });
      } catch (e) {
        const msg = String((e && e.message) || e);
        note.textContent = /cancel/i.test(msg)
          ? "Nothing was removed."
          : "Couldn't open the remove window from here. Please follow the steps below instead.";
      }
    };
  }

  /* ---------- stop autoplay ---------- */
  function bindStopAutoplay() {
    const en = $("saEnabled"), ot = $("saOnlyTimer");
    en.checked = settings.stopAutoplay.enabled;
    ot.checked = settings.stopAutoplay.onlyWithTimer;
    en.onchange = () => { settings.stopAutoplay.enabled = en.checked; queueSave(); };
    ot.onchange = () => { settings.stopAutoplay.onlyWithTimer = ot.checked; queueSave(); };
    document.querySelectorAll("#saModeChoices .choice").forEach((b) => {
      b.onclick = () => { settings.stopAutoplay.mode = b.dataset.mode; queueSave(); };
    });
    refreshUi();
  }

  /* ---------- autoplay log ---------- */
  async function loadLog() {
    const { autoplayLog } = await chrome.storage.local.get("autoplayLog");
    const list = Array.isArray(autoplayLog) ? autoplayLog : [];
    $("saLog").textContent = list.length
      ? list.map((x) => `${new Date(x.t).toLocaleTimeString()}  ${x.m}`).join("\n")
      : "Nothing yet. Notes appear here while you watch Tubi with Stop autoplay on.";
  }

  function bindLog() {
    $("saLogCopy").onclick = async () => {
      try {
        await navigator.clipboard.writeText($("saLog").textContent);
        $("saLogNote").textContent = "Copied.";
      } catch (_) {
        $("saLogNote").textContent = "Couldn't copy. Select the text and copy it.";
      }
      setTimeout(() => { $("saLogNote").textContent = ""; }, 3000);
    };
    $("saLogClear").onclick = async () => {
      await chrome.storage.local.remove("autoplayLog");
      loadLog();
    };
    chrome.storage.onChanged.addListener((c, area) => {
      if (area === "local" && c.autoplayLog) loadLog();
    });
    loadLog();
  }

  /* ---------- troubleshooting report ---------- */
  const trimUrl = (u) => { try { const x = new URL(u); return x.origin + x.pathname; } catch (_) { return u ? String(u).slice(0, 60) : ""; } };

  async function buildReport() {
    const out = [];
    const add = (s) => out.push(s);
    const man = chrome.runtime.getManifest();
    add(`Tubi Sleep Timer v${man.version}  ·  report ${new Date().toString()}`);
    add(`Browser: ${navigator.userAgent}`);
    const s = await getSettings();
    const { endTime } = await chrome.storage.local.get("endTime");
    add(`\n== Settings ==`);
    add(`link: ${JSON.stringify({ ...s.afterClose.link, url: trimUrl(s.afterClose.link.url) })}`);
    add(`black: ${JSON.stringify(s.afterClose.black)}`);
    add(`timer running: ${endTime ? "yes, ends " + new Date(endTime).toLocaleTimeString() : "no"}`);

    add(`\n== Windows ==`);
    let wins = [];
    try { wins = await chrome.windows.getAll({ populate: true, windowTypes: ["normal", "popup", "app", "devtools"] }); } catch (e) { add("windows error: " + e); }
    for (const w of wins) {
      add(`window ${w.id}: type=${w.type} state=${w.state} focused=${w.focused} size=${w.width}x${w.height} at ${w.left},${w.top} tabs=${(w.tabs || []).length}`);
      for (const t of w.tabs || []) {
        add(`   tab ${t.id}${t.active ? " [active]" : ""}${t.audible ? " [audible]" : ""}${t.discarded ? " [discarded]" : ""}  ${trimUrl(t.url)}`);
      }
    }

    add(`\n== YouTube tabs (live check) ==`);
    let yts = [];
    try { yts = await chrome.tabs.query({ url: ["*://*.youtube.com/*", "*://youtu.be/*"] }); } catch (_) {}
    if (!yts.length) add("none open");
    for (const t of yts) {
      try {
        const [r] = await chrome.scripting.executeScript({
          target: { tabId: t.id },
          func: () => {
            const v = document.querySelector("video");
            return {
              visibility: document.visibilityState,
              pictureInPictureEnabled: document.pictureInPictureEnabled,
              pipElement: !!document.pictureInPictureElement,
              documentPiP: !!(window.documentPictureInPicture && window.documentPictureInPicture.window),
              video: v ? { paused: v.paused, muted: v.muted, disablePictureInPicture: v.disablePictureInPicture, readyState: v.readyState } : null
            };
          }
        });
        add(`tab ${t.id}: ${JSON.stringify(r.result)}`);
      } catch (e) { add(`tab ${t.id}: couldn't inspect (${e})`); }
    }

    add(`\n== Activity log (newest last) ==`);
    const { popoutLog } = await chrome.storage.local.get("popoutLog");
    const list = Array.isArray(popoutLog) ? popoutLog : [];
    if (!list.length) add("empty. Run a sleep timer with the black screen on, then run the report again.");
    for (const x of list.slice(-150)) {
      const t = new Date(x.t);
      const ts = t.toLocaleTimeString() + "." + String(t.getMilliseconds()).padStart(3, "0");
      add(`${ts}  [${x.src}] ${x.e}${x.d !== undefined ? "  " + JSON.stringify(x.d) : ""}`);
    }
    return out.join("\n");
  }

  function bindReport() {
    $("rpRun").onclick = async () => {
      $("rpOut").textContent = "Working…";
      try { $("rpOut").textContent = await buildReport(); }
      catch (e) { $("rpOut").textContent = "Report failed: " + e; }
    };
    $("rpCopy").onclick = async () => {
      try {
        await navigator.clipboard.writeText($("rpOut").textContent);
        $("rpNote").textContent = "Copied.";
      } catch (_) {
        $("rpNote").textContent = "Couldn't copy. Select the text and copy it.";
      }
      setTimeout(() => { $("rpNote").textContent = ""; }, 3000);
    };
    $("rpClear").onclick = async () => {
      await chrome.storage.local.remove("popoutLog");
      $("rpNote").textContent = "Cleared.";
      setTimeout(() => { $("rpNote").textContent = ""; }, 3000);
    };
  }

  /* ---------- after close ---------- */
  // Auto-start needs access to the link's site (YouTube is built in; others ask once).
  async function ensureHostAccess(url) {
    const n = normalizeUrl(url);
    if (!n) return true;
    const pattern = new URL(n).origin + "/*";
    try {
      if (await chrome.permissions.contains({ origins: [pattern] })) return true;
      const ok = await chrome.permissions.request({ origins: [pattern] });
      if (!ok) $("linkNote").textContent = "Without access to that site, auto-start is skipped.";
      return ok;
    } catch (_) {
      return false;
    }
  }

  function updateLinkNote() {
    const raw = settings.afterClose.link.url;
    const n = normalizeUrl(raw);
    $("linkNote").textContent = !raw
      ? "Paste the link to open."
      : n
        ? `Will open: ${new URL(n).hostname}`
        : "That doesn't look like a valid web link.";
  }

  function bindAfter() {
    const a = settings.afterClose;
    const le = $("linkEnabled"), lu = $("linkUrl"), ap = $("linkAutoPlay");
    const be = $("blackEnabled"), fsEl = $("blackFullscreen"), dl = $("blackDelay");
    le.checked = a.link.enabled;
    if (document.activeElement !== lu) lu.value = a.link.url;
    ap.checked = a.link.autoPlay;
    be.checked = a.black.enabled;
    fsEl.checked = a.black.fullscreen;
    $("blackClosePopout").checked = a.black.closePopout !== false;
    $("blackClosePopout").onchange = (e) => { settings.afterClose.black.closePopout = e.target.checked; queueSave(); };
    if (document.activeElement !== dl) dl.value = a.black.delaySeconds;
    updateLinkNote();

    // Property handlers (not addEventListener) so re-binding never stacks listeners.
    le.onchange = () => {
      settings.afterClose.link.enabled = le.checked;
      queueSave();
      if (le.checked && settings.afterClose.link.autoPlay) ensureHostAccess(settings.afterClose.link.url);
    };
    lu.oninput = () => { settings.afterClose.link.url = lu.value.trim(); updateLinkNote(); queueSave(); };
    ap.onchange = () => {
      settings.afterClose.link.autoPlay = ap.checked;
      queueSave();
      if (ap.checked) ensureHostAccess(settings.afterClose.link.url);
    };
    be.onchange = () => { settings.afterClose.black.enabled = be.checked; queueSave(); };
    fsEl.onchange = () => { settings.afterClose.black.fullscreen = fsEl.checked; queueSave(); };
    dl.oninput = () => {
      settings.afterClose.black.delaySeconds = clamp(parseInt(dl.value, 10) || 0, 0, 20);
      queueSave();
    };
    dl.onchange = () => { dl.value = settings.afterClose.black.delaySeconds; };
  }

  $("testAfter").addEventListener("click", async () => {
    const a = settings.afterClose;
    if (a.link.enabled && a.link.autoPlay) await ensureHostAccess(a.link.url);
    await saveNow();
    const note = $("testNote");
    try {
      const r = await chrome.runtime.sendMessage({ type: "test-after" });
      if (r && r.linkInvalid) note.textContent = "The link is on but isn't a valid web link.";
      else if (!r || (!r.link && !r.black)) note.textContent = "Turn on a switch above first.";
      else note.textContent = r.link && r.black
        ? "Started. The black screen appears after the wait. Press Esc there to leave fullscreen."
        : "Opened.";
    } catch (e) {
      note.textContent = "Couldn't reach the extension.";
    }
    setTimeout(() => { note.textContent = ""; }, 5000);
  });

  // Keep the switches in sync if they're flipped from the toolbar popup.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.settings || !changes.settings.newValue) return;
    const incoming = mergeSettings(changes.settings.newValue).afterClose;
    if (JSON.stringify(incoming) !== JSON.stringify(settings.afterClose)) {
      settings.afterClose = incoming;
      bindAfter();
    }
    const sa = mergeSettings(changes.settings.newValue).stopAutoplay;
    if (JSON.stringify(sa) !== JSON.stringify(settings.stopAutoplay)) {
      settings.stopAutoplay = sa;
      bindStopAutoplay();
    }
  });

  /* ---------- colors ---------- */
  const COLOR_GROUPS = [
    {
      title: "Popup & settings",
      keys: [
        ["bg", "Background"],
        ["surface", "Panels & buttons"],
        ["border", "Borders"],
        ["text", "Text"],
        ["muted", "Secondary text"],
        ["accent", "Accent / primary buttons"],
        ["accentText", "Text on accent"],
        ["danger", "Cancel button"],
        ["success", "Status (Tubi playing)"]
      ]
    },
    {
      title: "On-page warning popup",
      keys: [
        ["overlayBg", "Background"],
        ["overlayText", "Text"],
        ["overlayAccent", "Accent & progress bar"],
        ["overlayCount", "Countdown number"]
      ]
    }
  ];

  function renderColors() {
    const wrap = $("colors");
    wrap.textContent = "";
    for (const group of COLOR_GROUPS) {
      const h = document.createElement("h3");
      h.textContent = group.title;
      wrap.appendChild(h);
      const grid = document.createElement("div");
      grid.className = "color-grid";

      for (const [key, label] of group.keys) {
        const row = document.createElement("div");
        row.className = "color-row";
        row.innerHTML = `<span class="name"></span><input type="color"><code></code><button type="button" title="Reset this color">↺</button>`;
        row.querySelector(".name").textContent = label;
        const input = row.querySelector("input");
        const code = row.querySelector("code");
        input.value = settings.colors[key];
        code.textContent = settings.colors[key];

        input.addEventListener("input", () => {
          settings.colors[key] = input.value;
          code.textContent = input.value;
          applyTheme(settings.colors);
          queueSave();
        });
        row.querySelector("button").addEventListener("click", () => {
          settings.colors[key] = DEFAULT_SETTINGS.colors[key];
          input.value = settings.colors[key];
          code.textContent = settings.colors[key];
          applyTheme(settings.colors);
          queueSave();
        });
        grid.appendChild(row);
      }
      wrap.appendChild(grid);
    }
  }

  $("resetColors").addEventListener("click", () => {
    settings.colors = structuredClone(DEFAULT_SETTINGS.colors);
    applyTheme(settings.colors);
    renderColors();
    queueSave();
  });

  $("resetAll").addEventListener("click", async () => {
    if (!confirm("Reset all settings (warnings, general options and colors) to defaults?")) return;
    const keepMode = settings.ui.mode;
    settings = structuredClone(DEFAULT_SETTINGS);
    settings.ui.mode = keepMode;
    applyTheme(settings.colors);
    renderWarnings();
    bindGeneral();
    bindStopAutoplay();
    bindAfter();
    renderColors();
    refreshUi();
    await saveNow();
  });

  renderWarnings();
  bindGeneral();
  bindStopAutoplay();
  bindAfter();
  renderColors();
  bindLooks();
  bindLog();
  bindReport();
  refreshUi();
})();
