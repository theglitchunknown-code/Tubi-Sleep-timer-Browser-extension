// On-page warning popup. Lives in a closed shadow root so Tubi's CSS can't affect it.
(() => {
  if (window.__tubiSleepTimerLoaded) return;
  window.__tubiSleepTimerLoaded = true;

  const FALLBACK = {
    overlayBg: "#14111f",
    overlayText: "#ece9f5",
    overlayAccent: "#6d28d9",
    overlayCount: "#faf0c8"
  };

  let host = null;
  let tickTimer = null;
  let hideTimer = null;

  const safeColor = (c, fb) => (typeof c === "string" && /^#[0-9a-f]{3,8}$/i.test(c) ? c : fb);

  function onAccent(hex) {
    let h = hex.replace("#", "");
    if (h.length === 3) h = h.split("").map((c) => c + c).join("");
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    return (r * 299 + g * 587 + b * 114) / 1000 > 150 ? "#111111" : "#ffffff";
  }

  // In fullscreen only the fullscreen element's subtree is visible.
  function container() {
    const fs = document.fullscreenElement || document.webkitFullscreenElement;
    if (fs && fs.tagName !== "VIDEO" && fs.tagName !== "IFRAME") return fs;
    return document.documentElement;
  }

  function hide() {
    clearInterval(tickTimer);
    clearTimeout(hideTimer);
    tickTimer = hideTimer = null;
    if (host) {
      host.remove();
      host = null;
    }
  }

  function show(m) {
    hide();
    const c = m.colors || {};
    const bg = safeColor(c.overlayBg, FALLBACK.overlayBg);
    const text = safeColor(c.overlayText, FALLBACK.overlayText);
    const accent = safeColor(c.overlayAccent, FALLBACK.overlayAccent);
    const count = safeColor(c.overlayCount, FALLBACK.overlayCount);

    host = document.createElement("div");
    host.id = "tubi-sleep-timer-overlay";
    host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
    host.style.setProperty("--bg", bg);
    host.style.setProperty("--text", text);
    host.style.setProperty("--accent", accent);
    host.style.setProperty("--count", count);
    host.style.setProperty("--on-accent", onAccent(accent));
    host.style.setProperty("--scale", String(Math.min(2, Math.max(1, Number(m.scale) || 1))));

    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
      <style>
        .card {
          position: absolute; top: 28px; left: 50%; transform: translateX(-50%);
          min-width: min(92vw, calc(300px * var(--scale))); max-width: min(92vw, calc(460px * var(--scale)));
          background: var(--bg); color: var(--text);
          border: 1px solid var(--accent); border-radius: 14px;
          padding: 16px 18px; box-shadow: 0 10px 40px rgba(0,0,0,.55);
          font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
          font-size: calc(15px * var(--scale)); line-height: 1.4;
          pointer-events: auto; animation: pop .2s ease-out;
        }
        @keyframes pop { from { opacity: 0; transform: translate(-50%, -8px); } to { opacity: 1; transform: translate(-50%, 0); } }
        .msg { font-weight: 600; text-align: center; }
        .count { font-size: calc(46px * var(--scale)); font-weight: 800; color: var(--count); text-align: center;
                 font-variant-numeric: tabular-nums; line-height: 1.1; margin: 8px 0; }
        .bar { height: 5px; border-radius: 3px; background: rgba(127,127,127,.3); overflow: hidden; margin: 6px 0 12px; }
        .bar span { display: block; height: 100%; width: 100%; background: var(--accent); }
        .row { display: flex; gap: 8px; justify-content: center; margin-top: 12px; }
        .bar + .row { margin-top: 0; }
        button { font: inherit; cursor: pointer; border-radius: 8px; padding: calc(7px * var(--scale)) calc(14px * var(--scale));
                 border: 1px solid var(--accent); background: transparent; color: var(--text); }
        button.ext { background: var(--accent); color: var(--on-accent); }
        [hidden] { display: none !important; }
      </style>
      <div class="card" role="alertdialog" aria-live="assertive">
        <div class="msg"></div>
        <div class="count" hidden></div>
        <div class="bar" hidden><span></span></div>
        <div class="row">
          <button class="ext"></button>
          <button class="dismiss">Dismiss</button>
        </div>
      </div>`;

    const msgEl = shadow.querySelector(".msg");
    const countEl = shadow.querySelector(".count");
    const barEl = shadow.querySelector(".bar");
    const fill = shadow.querySelector(".bar span");
    const extBtn = shadow.querySelector(".ext");
    const dismissBtn = shadow.querySelector(".dismiss");

    msgEl.textContent = m.message || "";
    extBtn.textContent = `+${m.extendMinutes || 10} min`;
    extBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "extend", minutes: m.extendMinutes || 10 });
      hide();
    });
    dismissBtn.addEventListener("click", hide);

    container().appendChild(host);

    if (m.countdown) {
      countEl.hidden = false;
      barEl.hidden = false;
      const total = Math.max(1, m.endTime - Date.now());
      const update = () => {
        const left = m.endTime - Date.now();
        if (left <= 0) {
          chrome.runtime.sendMessage({ type: "check-close" });
          hide();
          return;
        }
        countEl.textContent = Math.ceil(left / 1000) + "s";
        fill.style.width = Math.min(100, (left / total) * 100) + "%";
      };
      update();
      tickTimer = setInterval(update, 250);
    } else if (m.hideAfter > 0) {
      hideTimer = setTimeout(hide, m.hideAfter * 1000);
    }
  }

  document.addEventListener("fullscreenchange", () => {
    if (host) container().appendChild(host);
  });
  document.addEventListener("webkitfullscreenchange", () => {
    if (host) container().appendChild(host);
  });

  chrome.runtime.onMessage.addListener((m) => {
    if (!m) return;
    if (m.type === "tubi-sleep:show") show(m);
    else if (m.type === "tubi-sleep:hide") hide();
  });

  /* ---------- stop autoplay ----------
     Tubi marks its own next-episode jumps with ?autoplay=true in the address, and
     we also watch the video itself (finished or nearly finished). When something new
     starts by itself, the video is paused and the tab goes to the Tubi home page.
     A click or key press right before the change means you chose it, and is left alone.
       mode "episode": stop after this episode, whatever comes next.
       mode "show":    let the next episodes of the same show play, and stop
                       when the show is done and something different starts.   */
  const MIN_CONTENT_SECONDS = 300; // shorter videos are ads/trailers, not content
  const WINDOW_MS = 3 * 60 * 1000; // how long after "finished" a new video counts as autoplay
  const MANUAL_MS = 4000;          // a click/key this soon before the change means you chose it
  const SEEN_MS = 60 * 1000;       // we must have been watching something just before
  const STATE_KEY = "__tubiSleepWatch";
  const LOG_MAX = 60;

  let cfg = { enabled: false, mode: "episode", onlyWithTimer: false };
  let theme = {};
  let timerRunning = false;
  let inputAt = 0;
  let st = null; // what this tab is currently watching

  const active = () => cfg.enabled && (!cfg.onlyWithTimer || timerRunning);

  function loadCfg() {
    try {
      chrome.storage.local.get(["settings", "endTime"], (r) => {
        if (chrome.runtime.lastError || !r) return;
        const sa = (r.settings && r.settings.stopAutoplay) || {};
        cfg = {
          enabled: !!sa.enabled,
          mode: sa.mode === "show" ? "show" : "episode",
          onlyWithTimer: !!sa.onlyWithTimer
        };
        theme = (r.settings && r.settings.colors) || {};
        timerRunning = !!(r.endTime && r.endTime > Date.now());
      });
    } catch (_) {}
  }

  // Short notes shown in Settings > All settings > Autoplay log, to help troubleshooting.
  function log(m) {
    try {
      chrome.storage.local.get("autoplayLog", (r) => {
        if (chrome.runtime.lastError) return;
        const list = Array.isArray(r && r.autoplayLog) ? r.autoplayLog : [];
        list.push({ t: Date.now(), m });
        chrome.storage.local.set({ autoplayLog: list.slice(-LOG_MAX) });
      });
    } catch (_) {}
  }

  // A small badge so you can see the guard is running on this page.
  function toast(text) {
    try {
      const h = document.createElement("div");
      h.style.cssText = "all:initial;position:fixed;top:14px;left:14px;z-index:2147483647;pointer-events:none;";
      h.style.setProperty("--bg", safeColor(theme.overlayBg, FALLBACK.overlayBg));
      h.style.setProperty("--text", safeColor(theme.overlayText, FALLBACK.overlayText));
      h.style.setProperty("--accent", safeColor(theme.overlayAccent, FALLBACK.overlayAccent));
      const sh = h.attachShadow({ mode: "closed" });
      sh.innerHTML =
        "<style>div{font:600 13px system-ui,-apple-system,'Segoe UI',sans-serif;background:var(--bg);" +
        "color:var(--text);border:1px solid var(--accent);border-radius:999px;padding:8px 14px;" +
        "box-shadow:0 6px 24px rgba(0,0,0,.5)}</style><div></div>";
      sh.querySelector("div").textContent = text;
      container().appendChild(h);
      setTimeout(() => h.remove(), 4000);
    } catch (_) {}
  }

  // Kept per tab so it survives Tubi doing a full page load between episodes.
  function readState() {
    try {
      const raw = sessionStorage.getItem(STATE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (_) {
      return null;
    }
  }
  function saveState() {
    try {
      if (st) sessionStorage.setItem(STATE_KEY, JSON.stringify({ ...st, inputAt }));
      else sessionStorage.removeItem(STATE_KEY);
    } catch (_) {}
  }

  // Works out which video a Tubi address is, e.g. /tv-shows/200179125/s06-e10-shirt-disturber
  function parseWatch(pathname) {
    const m = pathname.match(/\/(movies|tv-shows|videos?)\/(\d+)(?:\/([^/?#]*))?/i);
    if (!m) return null;
    const se = (m[3] || "").match(/^s(\d+)-e(\d+)/i);
    const s = se ? Number(se[1]) : null;
    const e = se ? Number(se[2]) : null;
    return { id: m[2], s, e, key: m[2] + (se ? ":" + s + "-" + e : "") };
  }

  const describe = (w) =>
    w.s != null ? `S${w.s}E${w.e} (id ${w.id})` : `video ${w.id}`;

  const urlSaysAutoplay = () => {
    try { return new URLSearchParams(location.search).get("autoplay") === "true"; } catch (_) { return false; }
  };

  // Is `next` the following episode of the same show as `prev`?
  function sameShowNext(prev, next) {
    if (prev.s == null || next.s == null) return false; // movies or unknown: can't tell
    if (prev.id === next.id) return true;               // same id in the address = same show
    return (
      (next.s === prev.s && next.e === prev.e + 1) ||   // next episode
      (next.s === prev.s + 1 && next.e === 1)           // first episode of next season
    );
  }

  function allVideos() {
    const out = [];
    document.querySelectorAll("video").forEach((v) => out.push(v));
    if (!out.length) {
      // Some players hide the video inside a shadow root.
      const walk = (root) => root.querySelectorAll("*").forEach((el) => {
        if (el.shadowRoot) {
          el.shadowRoot.querySelectorAll("video").forEach((v) => out.push(v));
          walk(el.shadowRoot);
        }
      });
      try { walk(document); } catch (_) {}
    }
    return out;
  }

  function mainVideo(vs) {
    let best = null;
    vs.forEach((v) => {
      const d = v.duration;
      if (isFinite(d) && d >= MIN_CONTENT_SECONDS && (!best || d > best.duration)) best = v;
    });
    return best;
  }

  function stopNow(reason) {
    log("STOPPED: " + reason + ". Sent to Tubi home.");
    allVideos().forEach((v) => {
      try { v.pause(); v.muted = true; } catch (_) {}
    });
    st = null;
    saveState();
    location.assign(location.origin + "/");
  }

  function adopt(cur) {
    st = { key: cur.key, id: cur.id, s: cur.s, e: cur.e, finished: false, seenAt: Date.now() };
    saveState();
  }

  const restored = readState();
  st = restored;
  if (st && st.inputAt) inputAt = st.inputAt;

  // The address now points at a different video than the one we were tracking.
  function handleChange(prev, cur, now) {
    const label = `${describe(prev)} → ${describe(cur)}`;
    // After a full page load, judge by when the page load began, not by how long it took.
    const ref = prev === restored ? Math.min(now, performance.timeOrigin + 500) : now;

    const finishedRecently = !!prev.finished && ref - (prev.finishedAt || 0) <= WINDOW_MS;
    const flagged = urlSaysAutoplay() && ref - (prev.seenAt || 0) <= SEEN_MS;
    if (!finishedRecently && !flagged) {
      log(`Opened ${describe(cur)} (not autoplay)`);
      return adopt(cur);
    }

    // A click/key just before the change = you chose it. The exception is the click that
    // jumped you to the end of the video (a click is how you'd skip ahead to test this).
    const recent = ref - inputAt < MANUAL_MS;
    const jumped = !!prev.finished && inputAt < (prev.finishedAt || 0);
    if (recent && !jumped) {
      log(`You picked it yourself: ${label} (left alone)`);
      return adopt(cur);
    }
    if (cfg.mode === "show" && sameShowNext(prev, cur)) {
      log(`Next episode of the same show: ${label} (allowed)`);
      return adopt(cur);
    }
    stopNow(
      `new video started by itself (${label}; ${finishedRecently ? "the last one had finished" : "Tubi marked it autoplay"}); ` +
      `stop after ${cfg.mode === "show" ? "the whole show" : "this episode"}`
    );
  }

  function trackVideo(now) {
    const vs = allVideos();
    const v = mainVideo(vs);
    if (!v) { // no video, or only ads right now
      st.noVideo = (st.noVideo || 0) + 1;
      if (st.noVideo === 40) {
        log(
          `Can't see the video on ${describe(st)}. video tags: ${vs.length}, iframes: ` +
          `${document.querySelectorAll("iframe").length}` +
          (vs.length ? ", durations: " + vs.map((x) => Math.round(x.duration)).join("/") : "")
        );
      }
      return;
    }
    st.noVideo = 0;

    const d = v.duration;
    const left = d - v.currentTime;
    const threshold = Math.max(60, d * 0.06); // roughly the credits
    const sameLength = !!st.finishedDur && Math.abs(d - st.finishedDur) <= 1;

    if (st.finished) {
      if (v.ended && sameLength && !st.ended) { st.ended = true; saveState(); }

      // A different video began playing without the address changing.
      if (
        cfg.mode === "episode" && !v.paused && v.currentTime < 10 &&
        (!sameLength || st.ended) &&
        now - st.finishedAt < WINDOW_MS && now - inputAt >= MANUAL_MS
      ) {
        stopNow(`a new video started by itself after ${describe(st)}; stop after this episode`);
        return;
      }
      if (!v.ended && sameLength && left > threshold * 3) {
        st.finished = false; // you scrubbed back
        log("You went back in the video, so it isn't finished after all");
        saveState();
      }
      return;
    }

    if (v.ended || left <= threshold) {
      st.finished = true;
      st.finishedAt = now;
      st.finishedDur = d;
      st.ended = !!v.ended;
      log(`${describe(st)} is ${v.ended ? "over" : "almost over"}. Watching for autoplay`);
      saveState();
    }
  }

  function tick() {
    if (!active()) return;
    const now = Date.now();
    const cur = parseWatch(location.pathname);

    if (!cur) { // home, search, etc.
      if (st) { st = null; saveState(); }
      return;
    }
    if (st && st.key !== cur.key) { handleChange(st, cur, now); return; }
    if (!st) {
      adopt(cur);
      log("Watching " + describe(cur));
      toast("🌙 Autoplay guard on · stops after " + (cfg.mode === "show" ? "the whole show" : "this episode"));
    }
    st.seenAt = now;
    trackVideo(now);
  }

  try {
    loadCfg();
    chrome.storage.onChanged.addListener((c, area) => {
      if (area === "local" && (c.settings || c.endTime)) loadCfg();
    });
  } catch (_) {}

  // Only real clicks/keys/taps count as "you did it", not scripted ones.
  const markInput = () => { inputAt = Date.now(); if (st) saveState(); };
  ["pointerdown", "keydown", "touchstart"].forEach((t) =>
    window.addEventListener(t, (e) => { if (e.isTrusted) markInput(); }, true)
  );
  window.addEventListener("popstate", markInput); // Back/Forward are yours too
  window.addEventListener("pagehide", saveState);

  setInterval(tick, 500);
})();
