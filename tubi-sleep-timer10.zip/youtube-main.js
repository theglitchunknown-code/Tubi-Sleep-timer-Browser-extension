// Runs inside the YouTube page itself (MAIN world), before YouTube's own scripts.
// YouTube opts in to automatic pop-out by registering an "enterpictureinpicture"
// media action. While the black sleep screen is open we hide that registration
// so the browser has nothing to pop out, then restore it afterwards.
(() => {
  const ms = navigator.mediaSession;
  if (!ms || ms.__sleepWrapped) return;
  ms.__sleepWrapped = true;
  const orig = ms.setActionHandler.bind(ms);
  let saved = null, block = false;

  ms.setActionHandler = function (action, handler) {
    if (action === "enterpictureinpicture") {
      saved = handler;
      if (block) { try { return orig(action, null); } catch (_) { return; } }
    }
    return orig(action, handler);
  };

  document.addEventListener("tubi-sleep-block-pip", (e) => {
    block = e.detail === "1";
    try { orig("enterpictureinpicture", block ? null : saved); } catch (_) {}
  });
})();
