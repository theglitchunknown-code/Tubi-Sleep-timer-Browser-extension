// Runs on YouTube. While the black sleep screen is open:
//  1) stop YouTube's automatic pop-out from being offered (via youtube-main.js), and
//  2) if a pop-out still appears, close it.
// It never changes the video, and it limits its retries so it can't fight you.
(() => {
  if (window.top !== window) return;
  let blackOpen = false, enabled = true, lastBlock = null;
  let attempts = []; // timestamps of recent close attempts

  const log = (event, data) => {
    try { chrome.runtime.sendMessage({ type: "dbg", event, data }, () => void chrome.runtime.lastError); } catch (_) {}
  };
  const pipState = () => {
    const v = document.querySelector("video");
    return {
      pipEl: !!document.pictureInPictureElement,
      docPip: !!(window.documentPictureInPicture && window.documentPictureInPicture.window),
      vis: document.visibilityState,
      paused: v ? v.paused : null
    };
  };

  const setBlock = () => {
    const want = blackOpen && enabled;
    if (want === lastBlock) return;
    lastBlock = want;
    document.dispatchEvent(new CustomEvent("tubi-sleep-block-pip", { detail: want ? "1" : "0" }));
    log(want ? "auto pop-out blocked" : "auto pop-out allowed again", pipState());
    attempts = [];
    if (want) tryClose("black opened");
  };

  const tryClose = (why) => {
    if (!blackOpen || !enabled) return;
    const st = pipState();
    if (!st.pipEl && !st.docPip) return;
    const now = Date.now();
    attempts = attempts.filter((t) => now - t < 20000);
    if (attempts.length >= 5) { log("gave up closing", { why }); return; }
    attempts.push(now);
    log("closing pop-out", { why, n: attempts.length, ...st });
    try { if (document.pictureInPictureElement) document.exitPictureInPicture().catch((e) => log("exit failed", String(e))); } catch (e) { log("exit threw", String(e)); }
    try { if (window.documentPictureInPicture && window.documentPictureInPicture.window) window.documentPictureInPicture.window.close(); } catch (_) {}
  };

  document.addEventListener("enterpictureinpicture", () => { log("enterpictureinpicture", pipState()); tryClose("entered"); }, true);
  document.addEventListener("leavepictureinpicture", () => log("leavepictureinpicture", pipState()), true);
  document.addEventListener("visibilitychange", () => log("visibility " + document.visibilityState, pipState()), true);

  const read = async () => {
    try {
      const { blackOpen: b } = await chrome.storage.local.get("blackOpen");
      const { settings } = await chrome.storage.local.get("settings");
      blackOpen = !!b;
      enabled = !(settings && settings.afterClose && settings.afterClose.black && settings.afterClose.black.closePopout === false);
      setBlock();
    } catch (_) {}
  };
  chrome.storage.onChanged.addListener((c, area) => { if (area === "local" && (c.blackOpen || c.settings)) read(); });
  read();
  setInterval(read, 3000); // safety net in case a change was missed
})();
