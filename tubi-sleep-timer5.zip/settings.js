// Shared by the background worker, popup and settings page.

const DEFAULT_SETTINGS = {
  extendMinutes: 10,
  showBadge: true,
  alwaysShowTimer: false,
  ui: { mode: "simple", textSize: 1 },
  stopAutoplay: { enabled: false, mode: "episode", onlyWithTimer: false },
  afterClose: {
    link: { enabled: false, url: "", autoPlay: true },
    black: { enabled: false, fullscreen: true, delaySeconds: 5 }
  },
  warnings: [
    {
      id: "w5",
      enabled: true,
      seconds: 300,
      message: "Tubi will close in 5 minutes.",
      overlay: true,
      notify: false,
      countdown: false,
      hideAfter: 10
    },
    {
      id: "w1",
      enabled: true,
      seconds: 60,
      message: "Tubi is closing in 1 minute.",
      overlay: true,
      notify: true,
      countdown: true,
      hideAfter: 0
    },
    {
      id: "w30",
      enabled: true,
      seconds: 30,
      message: "Tubi is closing in 30 seconds.",
      overlay: true,
      notify: false,
      countdown: true,
      hideAfter: 0
    }
  ],
  colors: {
    bg: "#14111f",
    surface: "#231e36",
    border: "#3a3358",
    text: "#ece9f5",
    muted: "#9b94b8",
    accent: "#6d28d9",
    accentText: "#ffffff",
    danger: "#3a1620",
    success: "#7ee2a8",
    overlayBg: "#14111f",
    overlayText: "#ece9f5",
    overlayAccent: "#6d28d9",
    overlayCount: "#faf0c8"
  }
};

function mergeSettings(stored) {
  const d = structuredClone(DEFAULT_SETTINGS);
  if (!stored || typeof stored !== "object") return d;
  const out = { ...d, ...stored };
  out.colors = { ...d.colors, ...(stored.colors || {}) };
  out.stopAutoplay = { ...d.stopAutoplay, ...(stored.stopAutoplay || {}) };
  out.ui = { ...d.ui, ...(stored.ui || {}) };
  const ac = stored.afterClose || {};
  out.afterClose = {
    link: { ...d.afterClose.link, ...(ac.link || {}) },
    black: { ...d.afterClose.black, ...(ac.black || {}) }
  };
  const sw = Array.isArray(stored.warnings) ? stored.warnings : [];
  out.warnings = d.warnings.map((w, i) => ({ ...w, ...(sw[i] || {}), id: w.id }));
  return out;
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return mergeSettings(settings);
}

// Returns a clean http(s) URL string, or null if the input isn't a usable web link.
function normalizeUrl(input) {
  let u = (input || "").trim();
  if (!u) return null;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = "https://" + u;
  try {
    const x = new URL(u);
    return x.protocol === "https:" || x.protocol === "http:" ? x.href : null;
  } catch (_) {
    return null;
  }
}

const THEME_VARS = {
  bg: "--bg",
  surface: "--surface",
  border: "--border",
  text: "--text",
  muted: "--muted",
  accent: "--accent",
  accentText: "--accent-text",
  danger: "--danger",
  success: "--success",
  overlayBg: "--ov-bg",
  overlayText: "--ov-text",
  overlayAccent: "--ov-accent",
  overlayCount: "--ov-count"
};

// Same keys as DEFAULT_SETTINGS.colors. Black and white with yellow accents.
const HIGH_CONTRAST_COLORS = {
  bg: "#000000",
  surface: "#1a1a1a",
  border: "#ffffff",
  text: "#ffffff",
  muted: "#e6e6e6",
  accent: "#ffd400",
  accentText: "#000000",
  danger: "#8a0000",
  success: "#5dff94",
  overlayBg: "#000000",
  overlayText: "#ffffff",
  overlayAccent: "#ffd400",
  overlayCount: "#ffd400"
};

// Pages only (needs `document`). Makes everything bigger for easier reading.
function applyUi(ui) {
  const z = Math.min(2, Math.max(1, Number(ui && ui.textSize) || 1));
  document.documentElement.style.zoom = String(z);
}

// Pages only (needs `document`).
function applyTheme(colors) {
  const root = document.documentElement.style;
  for (const key in THEME_VARS) {
    if (colors[key]) root.setProperty(THEME_VARS[key], colors[key]);
  }
}
