importScripts("settings.js");

const TUBI_URLS = [
  "*://tubitv.com/*",
  "*://*.tubitv.com/*",
  "*://tubi.tv/*",
  "*://*.tubi.tv/*"
];

const CLOSE = "sleep-close";
const WARN_PREFIX = "sleep-warn-";
const MSG_SHOW = "tubi-sleep:show";
const MSG_HIDE = "tubi-sleep:hide";
const BLACK_URL = chrome.runtime.getURL("black.html");

let closing = false;

/* ---------- helpers ---------- */

async function sendToTubi(msg, { inject = true } = {}) {
  const tabs = await chrome.tabs.query({ url: TUBI_URLS });
  let delivered = 0;
  await Promise.all(
    tabs.map(async (t) => {
      try {
        await chrome.tabs.sendMessage(t.id, msg);
        delivered++;
      } catch (_) {
        if (!inject) return;
        // Tab was open before the extension loaded: inject then retry.
        try {
          await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["content.js"] });
          await chrome.tabs.sendMessage(t.id, msg);
          delivered++;
        } catch (_) {}
      }
    })
  );
  return delivered;
}

function notify(id, title, message) {
  chrome.notifications.create(id, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message
  });
}

function setBadge(s, active) {
  if (active && s.showBadge) {
    chrome.action.setBadgeBackgroundColor({ color: s.colors.accent });
    if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: s.colors.accentText });
    chrome.action.setBadgeText({ text: "ON" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

async function closeTabs(tabs) {
  const ids = tabs.map((t) => t.id).filter((id) => id !== undefined);
  if (ids.length) await chrome.tabs.remove(ids);
  return ids.length;
}

/* ---------- after-close sequence ----------
   1. open the link in front (or the black screen if there's no link)
   2. close Tubi
   3. wait for the link to load, click play for you
   4. after a short wait, open the black screen in front and go fullscreen   */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function createTab(props, windowId) {
  try {
    return await chrome.tabs.create(windowId !== undefined ? { ...props, windowId } : props);
  } catch (_) {
    return chrome.tabs.create(props); // window may be gone; fall back to the current one
  }
}

function waitForLoad(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    };
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === "complete") finish();
    };
    const timer = setTimeout(finish, timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((t) => { if (t.status === "complete") finish(); }).catch(finish);
  });
}

// Runs inside the page (must be self-contained). Gets the video playing.
async function autoPlayInPage() {
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const deadline = Date.now() + 12000;
  let sawVideo = false;
  while (Date.now() < deadline) {
    const v = document.querySelector("video");
    if (v) {
      sawVideo = true;
      if (!v.paused && !v.ended) return { state: "playing" };
      try { await v.play(); } catch (_) {}
      if (!v.paused) return { state: "playing" };
      const btn = document.querySelector(".ytp-large-play-button, .ytp-play-button");
      if (btn) btn.click();
      await wait(1500);
      if (!v.paused) return { state: "playing" };
      const player = document.querySelector("#movie_player, .html5-video-player");
      if (player) player.click();
      await wait(1500);
      if (!v.paused) return { state: "playing" };
    }
    await wait(500);
  }
  return { state: sawVideo ? "blocked" : "novideo" };
}

// Returns "playing", "blocked" (video found but wouldn't start) or "skipped".
async function tryAutoPlay(tabId, url) {
  try {
    const pattern = new URL(url).origin + "/*";
    if (!(await chrome.permissions.contains({ origins: [pattern] }))) return "skipped";
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: autoPlayInPage });
    const state = res && res.result && res.result.state;
    return state === "playing" ? "playing" : state === "blocked" ? "blocked" : "skipped";
  } catch (_) {
    return "skipped";
  }
}

async function goFullscreen(windowId) {
  try {
    const w = await chrome.windows.get(windowId);
    await chrome.storage.local.set({ preFsState: w.state === "fullscreen" ? "maximized" : w.state });
    await chrome.windows.update(windowId, { state: "fullscreen" });
  } catch (_) {}
}

// Step 1: opens the first tab. Returns what is enabled plus state for finishAfterClose.
async function openFirstAfterClose(s, windowId) {
  const a = s.afterClose;
  const link = a.link.enabled ? normalizeUrl(a.link.url) : null;
  const black = !!a.black.enabled;
  const result = { link: !!link, black, linkInvalid: a.link.enabled && !link };
  const state = { link, black, linkTab: null, blackTab: null };

  if (link) state.linkTab = await createTab({ url: link, active: true }, windowId);
  else if (black) state.blackTab = await createTab({ url: BLACK_URL, active: true }, windowId);
  return { result, state };
}

// Steps 3-4: click play, switch to the black screen, go fullscreen.
async function finishAfterClose(s, state) {
  const a = s.afterClose;
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);
  try {
    if (state.linkTab) {
      const tabId = state.linkTab.id;
      const winId = state.linkTab.windowId;
      await waitForLoad(tabId, 15000);

      let play = "skipped";
      if (a.link.autoPlay) play = await tryAutoPlay(tabId, state.link);
      if (!state.black) return;

      if (play === "blocked") {
        // Don't hide a video that still needs a click: park the black screen behind it.
        await createTab({ url: BLACK_URL, active: false }, winId);
        notify(
          "sleep-blocked",
          "Tubi Sleep Timer",
          "The video needs one click to start. Press play, then switch to the black screen tab."
        );
        return;
      }

      const wait = Math.min(20, Math.max(0, Number(a.black.delaySeconds) || 0));
      if (wait) await sleep(wait * 1000);
      state.blackTab = await createTab({ url: BLACK_URL, active: true }, winId);
    }

    if (state.blackTab && a.black.fullscreen) await goFullscreen(state.blackTab.windowId);
  } finally {
    clearInterval(keepAlive);
  }
}

/* ---------- timer ---------- */

async function clearWarnAlarms() {
  const all = await chrome.alarms.getAll();
  await Promise.all(
    all.filter((a) => a.name.startsWith(WARN_PREFIX)).map((a) => chrome.alarms.clear(a.name))
  );
}

async function scheduleWarnings(endTime, s) {
  await clearWarnAlarms();
  const now = Date.now();
  for (const w of s.warnings) {
    if (!w.enabled) continue;
    const fireAt = endTime - w.seconds * 1000;
    if (fireAt > now + 1000) chrome.alarms.create(WARN_PREFIX + w.id, { when: fireAt });
  }
}

async function startTimer(endTime) {
  await clearTimer(true);
  await chrome.storage.local.set({ endTime });
  const s = await getSettings();
  chrome.alarms.create(CLOSE, { when: endTime });
  await scheduleWarnings(endTime, s);
  setBadge(s, true);
}

async function clearTimer(hide) {
  await chrome.alarms.clear(CLOSE);
  await clearWarnAlarms();
  await chrome.storage.local.remove("endTime");
  chrome.action.setBadgeText({ text: "" });
  if (hide) await sendToTubi({ type: MSG_HIDE }, { inject: false });
}

async function doClose() {
  if (closing) return;
  closing = true;
  try {
    const { endTime } = await chrome.storage.local.get("endTime");
    if (!endTime) return;
    await clearTimer(false);
    const tabs = await chrome.tabs.query({ url: TUBI_URLS });
    const target = tabs.find((t) => t.audible) || tabs[0];
    const s = await getSettings();

    // Open the first follow-up tab before closing Tubi so the window is never left empty.
    let opened = { link: false, black: false };
    let state = null;
    try {
      ({ result: opened, state } = await openFirstAfterClose(s, target ? target.windowId : undefined));
    } catch (_) {}

    const n = await closeTabs(tabs);

    if (!opened.link && !opened.black) {
      notify(
        "sleep-done",
        "Sleep timer finished",
        n ? "Closed your Tubi tab. Sleep well!" : "No Tubi tab was open."
      );
    } else if (state) {
      // Skip the toast in a sleep setup (it could make a sound).
      try { await finishAfterClose(s, state); } catch (_) {}
    }
  } finally {
    closing = false;
  }
}

/* ---------- warnings ---------- */

function warningPayload(w, s, endTime) {
  return {
    type: MSG_SHOW,
    message: w.message,
    endTime,
    countdown: !!(w.countdown && w.seconds <= 60),
    hideAfter: w.hideAfter,
    extendMinutes: s.extendMinutes,
    scale: s.ui.textSize,
    colors: s.colors
  };
}

async function showWarning(w, s, endTime) {
  if (w.overlay) await sendToTubi(warningPayload(w, s, endTime));
  if (w.notify) notify("sleep-warn-" + w.id, "Tubi Sleep Timer", w.message);
}

async function preview(id) {
  const s = await getSettings();
  const w = s.warnings.find((x) => x.id === id);
  if (!w) return 0;
  const countdown = w.countdown && w.seconds <= 60;
  const endTime = Date.now() + (countdown ? Math.min(w.seconds, 10) : w.seconds) * 1000;
  let shown = 0;
  if (w.overlay) shown = await sendToTubi(warningPayload(w, s, endTime));
  if (w.notify) notify("sleep-preview", "Tubi Sleep Timer (preview)", w.message);
  return shown;
}

/* ---------- events ---------- */

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const { endTime } = await chrome.storage.local.get("endTime");
  if (!endTime) return;

  if (alarm.name === CLOSE) {
    await doClose();
  } else if (alarm.name.startsWith(WARN_PREFIX)) {
    const id = alarm.name.slice(WARN_PREFIX.length);
    const s = await getSettings();
    const w = s.warnings.find((x) => x.id === id);
    if (!w || !w.enabled) return;
    if (endTime - w.seconds * 1000 > Date.now() + 3000) return; // stale alarm
    await showWarning(w, s, endTime);
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case "start":
          await startTimer(msg.endTime);
          sendResponse({ ok: true });
          break;
        case "cancel":
          await clearTimer(true);
          sendResponse({ ok: true });
          break;
        case "extend": {
          const { endTime } = await chrome.storage.local.get("endTime");
          const mins = Math.min(720, Math.max(1, Number(msg.minutes) || 10));
          if (endTime) await startTimer(Math.max(endTime, Date.now()) + mins * 60000);
          sendResponse({ ok: true });
          break;
        }
        case "preview":
          sendResponse({ ok: true, shown: await preview(msg.id) });
          break;
        case "test-after": {
          const s = await getSettings();
          const { result, state } = await openFirstAfterClose(s, undefined);
          sendResponse({ ok: true, ...result });
          if (result.link || result.black) {
            try { await finishAfterClose(s, state); } catch (_) {}
          }
          break;
        }
        case "check-close": {
          // Sent by the on-page countdown as a backup in case the alarm is late.
          const { endTime } = await chrome.storage.local.get("endTime");
          if (endTime && Date.now() >= endTime - 1000) await doClose();
          sendResponse({ ok: true });
          break;
        }
        default:
          sendResponse({ ok: false });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  })();
  return true;
});

// Re-schedule warnings / badge when settings change while a timer is running.
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== "local" || !changes.settings) return;
  const { endTime } = await chrome.storage.local.get("endTime");
  if (!endTime) return;
  const s = await getSettings();
  await scheduleWarnings(endTime, s);
  setBadge(s, true);
});

async function restore() {
  const { endTime } = await chrome.storage.local.get("endTime");
  if (!endTime) return;
  if (endTime <= Date.now()) {
    await clearTimer(false);
    return;
  }
  const existing = await chrome.alarms.get(CLOSE);
  if (!existing) await startTimer(endTime);
  else setBadge(await getSettings(), true);
}

chrome.runtime.onStartup.addListener(restore);
chrome.runtime.onInstalled.addListener(restore);
