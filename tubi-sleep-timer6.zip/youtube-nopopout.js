// Runs on YouTube. While the black sleep screen is open, keep the video from
// floating out as a pop-out / Picture-in-Picture window. Audio keeps playing.
(() => {
  let blackOpen = false;

  const closePopout = () => {
    try {
      if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
    } catch (_) {}
  };

  const apply = () => {
    document.querySelectorAll("video").forEach((v) => {
      try {
        v.disablePictureInPicture = blackOpen; // stops the pop-out from being offered
        if (blackOpen && !v.__sleepNoPip) {
          v.__sleepNoPip = true;
          v.addEventListener("enterpictureinpicture", closePopout);
        }
      } catch (_) {}
    });
    try {
      if (blackOpen && navigator.mediaSession) {
        // Blocks the browser's automatic "enter picture-in-picture" when you leave the tab.
        navigator.mediaSession.setActionHandler("enterpictureinpicture", () => {});
      }
    } catch (_) {}
    if (blackOpen) closePopout();
  };

  const check = () => {
    try {
      chrome.runtime.sendMessage({ type: "black-open?" }, (r) => {
        if (chrome.runtime.lastError) return;
        blackOpen = !!(r && r.open);
        apply();
      });
    } catch (_) {}
  };

  check();
  setInterval(check, 1000); // pop-out can appear the moment the tab loses focus
  document.addEventListener("visibilitychange", check);
  new MutationObserver(() => { if (blackOpen) apply(); }).observe(document.documentElement, { childList: true, subtree: true });
})();
